<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-nd-4 mt-5">
            <form action="<?php echo e(route('vehiculo.update',$vehiculos->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>
                <table class="table">
                    <tbody>
                    <tr>
                        <th>placa</th>
                        <td> <input type="text" name="placa" class="form-control" value="<?php echo e($vehiculos->placa); ?>">}</td>
                    </tr>
                    <tr>
                        <th>color</th>
                        <td> <input type="text" name="color" class="form-control" value="<?php echo e($vehiculos->color); ?>">}</td>
                    </tr>
                    <tr>
                        <th>Correo</th>
                        <td> <input type="text" name="marca" class="form-control" value="<?php echo e($vehiculos->marca); ?>">}</td>
                    </tr>
                    <tr>
                        <th>tipo vehiculo</th>
                        <td> <input type="text" name="tipovehiculo" class="form-control" value="<?php echo e($vehiculos->tipovehiculo); ?>">}</td>
                    </tr>
                    <tr>
                        <th>Conductor</th>
                        <td> <input type="text" name="conductor" class="form-control" value="<?php echo e($vehiculos->conductor); ?>">}</td>
                    </tr>
                    <tr>
                        <th>propietario</th>
                        <td> <input type="text" name="propietario" class="form-control" value="<?php echo e($vehiculos->propietario); ?>">}</td>
                    </tr>
                    </tbody>
                </table>
                <a href="<?php echo e(route('vehiculo.index')); ?>" class="btn btn-default">CANCELAR</a>
                <button type="submit" class="btn btn-primary">GUARDAR CAMBIOS</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>

<?php /**PATH C:\Users\dandr\Documents\laravel\primer-proyecto\resources\views/vehiculo/edit.blade.php ENDPATH**/ ?>