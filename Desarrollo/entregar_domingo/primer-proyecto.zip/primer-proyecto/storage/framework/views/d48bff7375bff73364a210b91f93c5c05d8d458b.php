<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <title>Vehiculos</title>
</head>
<body>
<div class="container">
    <div class="row">

        <div class="col-md-12">
            <a href="<?php echo e(route('vehiculo.create')); ?>" class="btn btn-primary mt-5">CREAR VEHICULO</a>
            <a href="<?php echo e(route('vehiculo.create')); ?>" class="btn btn-primary mt-5">VER INFORME</a>
            <a href="<?php echo e(route('principal.inicio')); ?>" class="btn btn-primary mt-5">INICIO</a>
            <div class="table-responsive">
                <table class="table table-bordered ">
                    <thead>
                    <tr>
                        <th>PLACA</th>
                        <th>COLOR</th>
                        <th>MARCA</th>
                        <th>TIPO DE VEHICULO</th>
                        <th>CONDUCTOR</th>
                        <th>PROPIETARIO</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiculos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($vehiculos->placa); ?></td>
                            <td><?php echo e($vehiculos->color); ?></td>
                            <td><?php echo e($vehiculos->marca); ?></td>
                            <td><?php echo e($vehiculos->tipovehiculo); ?></td>
                            <td><?php echo e($vehiculos->conductor); ?></td>
                            <td><?php echo e($vehiculos->propietario); ?></td>
                            <td><?php echo e($vehiculos->created_at); ?></td>
                            <td>
                                <form action="<?php echo e(route('vehiculo.destroy',$vehiculos->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a href="<?php echo e(route('vehiculo.show',$vehiculos->id)); ?>" class="btn btn-primary">Detalles</a>
                                    <a href="<?php echo e(route('vehiculo.edit',$vehiculos->id)); ?>" class="btn btn-primary">Editar</a>
                                    <button type="submit" class="btn btn-primary">Eliminar</button>

                                </form>

                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>
</body>
</html>

<?php /**PATH C:\Users\dandr\Documents\laravel\primer-proyecto\resources\views/vehiculo/index.blade.php ENDPATH**/ ?>