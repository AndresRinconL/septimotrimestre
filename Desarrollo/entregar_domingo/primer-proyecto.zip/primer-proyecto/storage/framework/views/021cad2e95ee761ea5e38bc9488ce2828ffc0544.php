<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <title></title>
    <title>Detalles</title>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-6 offset-md-3">
            <table class="table">
                <tbody>
                <tr>
                    <th>tipo usuario</th>
                    <td><?php echo e($user->tipousuario); ?></td>
                </tr>
                <tr>
                    <th>numero cedula</th>
                    <td><?php echo e($user->numerocedula); ?></td>
                </tr>
                <tr>
                    <th>nombres</th>
                    <td><?php echo e($user->nombres); ?></td>
                </tr>
                <tr>
                    <th>apellidos</th>
                    <td><?php echo e($user->apellidos); ?></td>
                </tr>
                <tr>
                    <th>direccion</th>
                    <td><?php echo e($user->direccion); ?></td>
                </tr>
                <tr>
                    <th>telefono</th>
                    <td><?php echo e($user->telefono); ?></td>
                </tr>
                <tr>
                    <th>ciudad</th>
                    <td><?php echo e($user->ciudad); ?></td>
                </tr>
                </tbody>
            </table>
            <a href="<?php echo e(route('user.index')); ?>" class="btn btn-default">VOLVER</a>
            <a href="<?php echo e(route('user.edit', $user->id)); ?>" class="btn btn-warning">EDITAR</a>
        </div>
    </div>
</div>
</body>
</html>


</body>
</html>


<?php /**PATH C:\Users\dandr\Documents\laravel\primer-proyecto\resources\views/user/show.blade.php ENDPATH**/ ?>