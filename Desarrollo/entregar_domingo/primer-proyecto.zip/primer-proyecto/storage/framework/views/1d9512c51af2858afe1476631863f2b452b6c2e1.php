<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge"><link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css">
    <title>Usuarios</title>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <a href="<?php echo e(route('user.create')); ?>" class="btn btn-primary mt-5">CREAR USUARIO</a>
            <a href="<?php echo e(route('principal.informe')); ?>" class="btn btn-primary mt-5">VER INFORME</a>
            <a href="<?php echo e(route('principal.inicio')); ?>" class="btn btn-primary mt-5">INICIO</a>

            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>TIPO USUARIO</th>
                        <th>NUMERO CEDULA</th>
                        <th>NOMBRES</th>
                        <th>APELLIDOS</th>
                        <th>DIRECCION</th>
                        <th>TELEFONO</th>
                        <th>CIUDAD</th>

                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($user->tipousuario); ?></td>
                            <td><?php echo e($user->numerocedula); ?></td>
                            <td><?php echo e($user->nombres); ?></td>
                            <td><?php echo e($user->apellidos); ?></td>
                            <td><?php echo e($user->direccion); ?></td>
                            <td><?php echo e($user->telefono); ?></td>
                            <td><?php echo e($user->ciudad); ?></td>
                            <td><?php echo e($user->created_at); ?></td>
                            <td>
                                <form action="<?php echo e(route('user.destroy',$user->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <a href="<?php echo e(route('user.show',$user->id)); ?>" class="btn btn-primary">DETALLES</a>
                                    <a href="<?php echo e(route('user.edit',$user->id)); ?>" class="btn btn-primary">EDITAR</a>
                                    <button type="submit" class="btn btn-primary">ELIMINAR</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\Users\dandr\Documents\laravel\primer-proyecto\resources\views/user/index.blade.php ENDPATH**/ ?>